def test_int():
    assert 1 == 1
