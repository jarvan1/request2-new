class Usuario:
    def __init__(self, nome, email):
        self.email = email
        self.nome = nome
        self.id = None
