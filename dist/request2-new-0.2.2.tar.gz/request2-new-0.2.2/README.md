# request2
[![Build Status](https://app.travis-ci.com/raphamoral/request2.svg?branch=master)](https://app.travis-ci.com/raphamoral/request2)
[![codecov](https://codecov.io/gh/raphamoral/request2/branch/master/graph/badge.svg)](https://codecov.io/gh/raphamoral/request2)

